# TJTECH
tjtech 3.0 jueves, 17 de septiembre de 2024. after closing in armani store... we did a good job and everything was good as we planned 
